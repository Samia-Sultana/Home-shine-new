
<?php $__env->startSection('gallery'); ?>


<section class="portfolio gallery">
    <div class="container">
        <div class="top-side">
            <h4 class="title">Gallery</h4>
            <h2>PORTFOLIO</h2>
        </div>

        <div class="filters">
            <ul>
                <?php
                $catagories = App\Models\Catagory::all();
                ?>
                <li class="active" data-filter="*">All</li>/
                <?php $__currentLoopData = $catagories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catagory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li data-filter=".<?php echo e($catagory->catagoryName); ?>"><?php echo e($catagory->catagoryName); ?></li>/
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>


        <div class="filters-content">
            <div class="row grid">
                <?php if($photos): ?>
                <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $catagoryDetail = App\Models\Catagory::find($photo->catagory_id);
                ?>
                <div class="col-sm-4 all <?php echo e($catagoryDetail->catagoryName); ?>">
                    <div class="item">
                        <img src="<?php echo e(url('photos/'.$photo->image)); ?>" alt="Work 1">
                        <div class="p-inner">
                            <h5>Work 1</h5>
                            <div class="cat"><?php echo e($catagoryDetail->catagoryName); ?></div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>

    </div>
</section>


<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
<script src="https://unpkg.com/isotope-layout@3/dist/isotope.pkgd.min.js"></script>
<script>
    
/*-----------------------------------
	  isotop gallery
	  -------------------------------------*/
	  $('.filters ul li').click(function(){
		$('.filters ul li').removeClass('active');
		$(this).addClass('active');
		
		var data = $(this).attr('data-filter');
		$grid.isotope({
		  filter: data
		})
	  });
	  
	  var $grid = $(".grid").isotope({
		itemSelector: ".all",
		percentPosition: true,
		masonry: {
		  columnWidth: ".all"
		}
	  })

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('masterUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AveenirIt_Projects\Home_Shine\resources\views/gallery.blade.php ENDPATH**/ ?>