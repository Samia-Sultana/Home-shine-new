
<?php $__env->startSection('about'); ?>
    

        <!--Body Content-->
        <div id="page-content">
            <!--Page Title-->
            <div class="page section-header text-center">
                <div class="page-title">
                    <div class="wrapper">
                        <h1 class="page-width">About Us</h1>
                    </div>
                </div>
            </div>
            <!--End Page Title-->

            <div class="container">
                <div class="row">
                    <div class="col-12 col-sm-12 col-md-12 col-lg-12 mb-4"><img class="blur-up lazyload" src="assets/images/banner/banner1.jpg" alt="About Us" /></div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <h2>Sed ut perspiciatis unde omnis iste natus error</h2>
                        <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure
                            of the moment, so blinded by desire, that they cannot foresee the pain.</p>
                        <p>simple and easy to distinguish. In a free hour, when our power of choice is untrammelled and when nothing prevents our being able to do what we like best, every pleasure is to be welcomed and every pain avoided. But in certain
                            circumstances and owing to the claims of duty or the obligations of business it will frequently occur that pleasures have to be repudiated and annoyances accepted.</p>
                        <p></p>
                    </div>
                </div>



            </div>

        </div>
        <!--End Body Content-->

      




        <!-- Including Jquery -->
        <script src="assets/js/vendor/jquery-3.3.1.min.js"></script>
        <script src="assets/js/vendor/modernizr-3.6.0.min.js"></script>
        <script src="assets/js/vendor/jquery.cookie.js"></script>
        <script src="assets/js/vendor/wow.min.js"></script>
        <script src="assets/js/vendor/instagram-feed.js"></script>
        <!-- Including Javascript -->
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/plugins.js"></script>
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/lazysizes.js"></script>
        <script src="assets/js/main.js"></script>
        <script src="assets/js/cart.js"></script>
        <script src="assets/alertifyjs/alertify.min.js"></script>
        <!--End Instagram Js-->
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('masterUser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\AveenirIt_Projects\Home_Shine\resources\views/about.blade.php ENDPATH**/ ?>