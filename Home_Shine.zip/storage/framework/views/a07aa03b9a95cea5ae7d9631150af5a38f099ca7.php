<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maknoon Lifestyle</title>

    <!---===========favicon=====-->
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('assets/img/logo/favicon/apple-touch-icon.png')); ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('assets/img/logo/favicon/favicon-32x32.png')); ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('assets/img/logo/favicon/favicon-16x16.png')); ?>">
    <link rel="manifest" href="<?php echo e(asset('assets/img/logo/favicon/site.webmanifest')); ?>">
    

    <!--======== Bootstrap 4.6===-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <!--======== font awesome===-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/fontawesome.min.css')); ?>">
    <!---======= owl carousel======-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.theme.default.min.css')); ?>">
    <!---======= Header css-->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/header-css/reset.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive.css')); ?>">


</head>

<?php echo $__env->make('user.userNavbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <?php echo $__env->yieldContent('userDashboard'); ?>
    <?php echo $__env->yieldContent('userCategoryProduct'); ?>


<?php echo $__env->make('user.userFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!---=====jquery====-->
    <script src="<?php echo e(asset('assets/js/jquery-3.6.0.min.js')); ?>"></script>
    <!--=====popper js=====-->
    <script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
    <!--=====bootstrap=====-->
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <!--=====Owl carousel=====-->
    <script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>
    <!--=====header script=====-->
    <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>

      <!--=====header script=====-->
    <!--===========zoom ============-->
    <script src="<?php echo e(asset('assets/js/swiper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/easyzoom.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.nice-select.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

</body>

</html><?php /**PATH C:\xampp\htdocs\AveenirIt_Projects\Ecom-CMS-3.0\resources\views/master.blade.php ENDPATH**/ ?>